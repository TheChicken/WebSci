README.md

So its 2:27am and I have been working on this project for days because I wanted it to be what I had imagined in my head. So.. there is a LOT more functionality than you asked for! 

That being said.. I really enjoyed learning the mongoDB part of this lab more indepthly than what we had covered in class. It was really fun and interesting to see how easy information can be added on the fly. I can see why this would be used for huge data collections. The read portion was a little frustrating at times dealing with string parsing and handling little odd things like the differnce in collectionNames and listCollections. I guess collectionNames was a previous version but ther was a lot of reference to it, so it took me a while to figure out what was what. The writing to a file part was easy considering the work we did last time with JSON and CSV files. I enjoyed adding the file name in this lab though - I wanted to do that in the past so I am glad we got around to it. 

Overall, I know I made this lab much more difficult than it needed to be but I really enjoyed seeing what I could do. I hope that the functionality/creativity I tried explains why I am handing it in a few hours late! 
	>>Added:
		Ability to choose a collection name and number of entries to retrieve to insert
		Ability to choose a collection name to read tweets from and number of entries to retrieve
		Ability to choose a collection name and number of entries from collection to read and export to XML 

	>> I tried to:
		Also let the user query the exisiting collection's text field for a specific keyword - it did not work though! You can see the notes in my code for more :) 

Oh - I did try to use page routing instead of the tabs that I have in this lab. I wasnt sure how to use routing with node server and am wondering if we will be learning that in class? I know we can use a wildcard but am not sure how to implement. I think i will be looking into it more for our project!