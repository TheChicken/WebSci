//create the app
var app = angular.module('twitterApp', []);
//create controller 
app.controller('TwitterController', ['$scope', '$http', function($scope, $http) {

//define the button and counter
$scope.button="Search";
$scope.count=10;
var count = $scope.count;

$scope.add=function(){
	count = count + 1;
	$scope.count=count;
}
$scope.dec=function(){
	count = count - 1;
	$scope.count=count;
}

$scope.getTweets=function(){

    var locations=$scope.query;

	$http.get('/tweets', {

		params: {"count": count, "geocode" : locations}

	}).then(function (response){
		//this callback will be called asynchronously when response is available 
		console.log("Got it");

		$scope.tweets=response.data;

	}, function errorCallback(response){
		//called asychronously if error occurs or server response with error status
	});
	}
}]);
