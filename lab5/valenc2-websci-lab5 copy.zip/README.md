Chelsea Valente
Lab 5 - NodeJS/Express

Wow. That was a doozy. 

So figuring out the API was the hardest part because you needed to both filter and ask for a count. I was able to get the count using client.get() but I wasnt able to filter. I wasnt sure how to go about this so I heard how other students were using an incremental counter within the stream. This wound up working so I kept it this way - however I would be curious as how to other students were able to get theirs done. I know that I could have used npm file writer instead of fs but I found fs much easier to use with the client.stream() so I kept fs. 

Thankfully there is a lot of documentation out there on these APIs and I like the way node works in conjucntion with angular. It is hard to get used to but it is very powerful. I wish the Twitter API didnt take so long though! But this was still a fun lab and I was able to get a decent grip on how it all works. 

