README.md

I was only a little over the midnight deadine and I was able to do everything I wanted to accomplish in this lab with the exception of one thing - so I think that is pretty good!

My lab was alreay in a web app form but last time I did it with tabs and really wanted to do angular page routing so I was able to complete that this time. It helped to organize my code as well. Next time I would like to break up app.js into a few different files as well! 

Secondly, I wanted to have a little more user interaction. I did add in some notifications/alerts last time but wanted a little more error control too. One additional interaction was disabling/enabling the install button according to weather there was a db already connected to or not. 

Lastly - and this is what took so long.. I really wanted the option to query against collections. What was the hardest part was trying to find a way to get a responsive slection drop down with the collection names in it which would help by not having to query the collection name against the collection list. However- it just wasnt working for me. I was able to get the search on the text field with the use of an index. That was something I wanted to complete in Lab 7 but never was able to figure it out. 

I didnt add too much to the overall css color/theme because I wanted more of the creativity to come from the user notifications, the overall design, and the ability to have increased functionality with the queries. 

This is never easy but I am really happy its done!
