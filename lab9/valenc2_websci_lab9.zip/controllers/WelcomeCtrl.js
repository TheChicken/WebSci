angular.module('mainApp');

  app.controller('WelcomeCtrl', ['$scope', '$http', function($scope, $http){


  }]);