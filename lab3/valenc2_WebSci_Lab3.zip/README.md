Chelsea Valente
README.md
Lab 3 - Git & Bugs

I have never been that great at GitHub - I dont think I understand the differences in branches and I keep updating things to the origin/master. I was able to set up my repository fairly easily through the GitHub Desktop GUI which I really enjoy using. Adding both of you was a simple task I perfomred on github.com

The second part however, was a little challenging becuase I still dont know much of what was going on. I know Carson was taking care of setting up the server and he gave us instructions on how to add the repo through git bash which were really easy to follow! I was able to very easily set up the connection. However.. I am still not sure on how to push and will have to clarify this with my team members who have more experience than I do. 

As far as the server link - I know we were having an issue with bugzilla and a module that will not load. If one of the modules fail then it wont load - lovely!! That was interesting. However, now things are up and running smoothly.

Part 1 - https://github.com/TheChicken/WebSci.git

Part 2 -server repo: http://carson.space/iAttend/

		to access remote git:
		git clone prof@carson.space:/var/www/html/iAttend/.git
		Your username/password are both prof

		Debugger:	http://carson.space/mantis/login_page.php
					U: administrator
					P: root

		local git: https://github.com/TheChicken/WebSci-iAttend.git