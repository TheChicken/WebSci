README.md

Bootstrap is pretty handy! This wasnt an excrusiating lab but it did take me a while to understand how to make the columns work and get the pictures next to eachother. 

The animation was a fun challenge. I was able to utilize jquery's slide down function and fade out which made the transitioning really nice. Luckily, there is a lot of documentation on this type of annimation. I was able to use things readily available in bootstrap documentation (the navbar came from here) as well as stackoverflow. 

It was REALLY HARD not to just use a plug-in!! There is SO much documentation on news tickers and so many plug-ins were written for all different types of transitions. However, I am glad I worked through the lab and was able to learn how to do these things. Quite a powerful functionality with not that much written code. 

Given more time I would have created a secondary ticker for the hashtags. I would have found a way to weigh them or rate them by popularity and display them based on that rank first and then maybe had them scroling or just keep the most popular ones displayed. 