Chelsea Valente
Web Science - Lab 2

For this lab, I used openweather's API and HTML5 Geolocation API to create a weather forecast. I first called the Geolocation to get he user's latitude and logitude which I then used in the AJAX url to call the openweather API. I used the jsonp return format we spoke about in class which was very useful when I needed to locate the properties returned from the API. Interestingly enough, when I first started this lab and just was concerned with finidng the local weather I was able to specify units=imperial in the URL. When I switched to the forcast API, I was able to get the max and min values in fahrenheit but the current temperature came in kelvin! I am not sure why that happened, but it was interesting to notice that difference. 

I had a lot of fun learning more about Bootstrap and getting more comfortable with the columns and rows. I started off a little frustrated but once I figured out how to start aligning things I really enjoyed it! I have to say that I am really proud of how this lab came out and I feel pretty accomplished! The only thing I would change is maybe dealing with the window resizing a little more gracefully. 

I did use some CSS for the styling but want to experiment more with the div classes span and offsets to let the structure really do the bulk of the work.